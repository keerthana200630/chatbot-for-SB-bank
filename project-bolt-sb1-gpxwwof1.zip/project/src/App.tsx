import React from 'react';
import ChatWidget from './components/ChatWidget';
import DemoContent from './components/DemoContent';

function App() {
  return (
    <div className="min-h-screen bg-neutral-50">
      <DemoContent />
      <ChatWidget />
    </div>
  );
}

export default App;