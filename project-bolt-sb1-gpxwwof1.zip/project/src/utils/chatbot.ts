import { BotResponse } from '../types/chat';

// Simple keyword-based response system
// In a real implementation, this would be connected to a backend NLP system
export const generateBotResponse = (query: string): BotResponse => {
  const lowerQuery = query.toLowerCase();
  
  // Banking-related keywords
  if (lowerQuery.includes('balance') || lowerQuery.includes('how much') || lowerQuery.includes('account balance')) {
    return {
      text: "To check your account balance, you'll need to log in to your online banking portal or mobile app. For security reasons, I can't access your account information directly. Would you like me to guide you through the login process?",
      quickReplies: ["Yes, guide me", "No thanks", "I can't log in", "Call customer service"]
    };
  }
  
  if (lowerQuery.includes('transaction') || lowerQuery.includes('recent')) {
    return {
      text: "You can view your recent transactions by logging into your SecureBank account. Would you like me to help you locate the transaction history section?",
      quickReplies: ["Yes, show me how", "Search for a transaction", "Download statement", "Speaking with a representative"]
    };
  }
  
  if (lowerQuery.includes('transfer') || lowerQuery.includes('send money')) {
    return {
      text: "I can help you transfer money between your accounts or to another person. What type of transfer would you like to make?",
      quickReplies: ["Between my accounts", "To another person", "International transfer", "Schedule recurring transfer"]
    };
  }
  
  if (lowerQuery.includes('lost') || lowerQuery.includes('stolen') || lowerQuery.includes('card')) {
    return {
      text: "I'm sorry to hear about your card. We should block it immediately to protect your account. Would you like me to help you report your lost/stolen card now?",
      quickReplies: ["Yes, block my card", "No, just checking", "Help with temporary card", "Order replacement"]
    };
  }
  
  if (lowerQuery.includes('loan') || lowerQuery.includes('mortgage') || lowerQuery.includes('borrow')) {
    return {
      text: "We offer various loan products to meet your needs. What type of loan are you interested in?",
      quickReplies: ["Personal loan", "Mortgage", "Auto loan", "Education loan", "Business loan"]
    };
  }
  
  if (lowerQuery.includes('interest') || lowerQuery.includes('rate')) {
    return {
      text: "Our current interest rates vary by product and your credit profile. Which specific product would you like to know the rates for?",
      quickReplies: ["Savings accounts", "Checking accounts", "Mortgages", "Personal loans", "Credit cards"]
    };
  }
  
  if (lowerQuery.includes('fee') || lowerQuery.includes('charge')) {
    return {
      text: "We try to keep our fees transparent and minimal. Which specific fee would you like information about?",
      quickReplies: ["Monthly maintenance", "Overdraft fees", "ATM fees", "Wire transfer fees", "Late payment fees"]
    };
  }
  
  if (lowerQuery.includes('login') || lowerQuery.includes('password') || lowerQuery.includes('forgot')) {
    return {
      text: "If you're having trouble logging in, I can help you reset your password or unlock your account. What issues are you experiencing?",
      quickReplies: ["Forgot password", "Account locked", "Technical problems", "Speak to security team"]
    };
  }
  
  if (lowerQuery.includes('open') || lowerQuery.includes('new account')) {
    return {
      text: "I'd be happy to help you open a new account with SecureBank. What type of account are you interested in?",
      quickReplies: ["Checking account", "Savings account", "Joint account", "Business account", "Investment account"]
    };
  }
  
  if (lowerQuery.includes('human') || lowerQuery.includes('agent') || lowerQuery.includes('representative') || lowerQuery.includes('person')) {
    return {
      text: "I'd be happy to connect you with a human customer support representative. Our agents are available Monday-Friday 8am-8pm and Saturday 9am-5pm. Would you like me to initiate a transfer to a human agent now?",
      quickReplies: ["Yes, connect me", "No, continue with chatbot", "Schedule callback", "Send email instead"]
    };
  }
  
  // Fallback responses
  const fallbackResponses = [
    {
      text: "I'm not sure I understand your question. Could you please rephrase or select one of these common banking topics?",
      quickReplies: ["Account information", "Card services", "Loans & mortgages", "Online banking help", "Speak to a human"]
    },
    {
      text: "I want to make sure I assist you correctly. Could you provide more details about what you're looking for?",
      quickReplies: ["Account services", "Banking products", "Technical support", "Report an issue", "Contact us"]
    },
    {
      text: "I'm still learning and didn't quite catch that. What category of banking services are you interested in?",
      quickReplies: ["Accounts & deposits", "Cards & payments", "Loans & credit", "Digital banking", "Other services"]
    }
  ];
  
  // Return a random fallback response
  return fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
};