export interface Message {
  id: number;
  text: string;
  isUser: boolean;
  timestamp: Date;
  quickReplies?: string[];
}

export interface ChatState {
  messages: Message[];
  isTyping: boolean;
  currentQuery: string;
}

export interface BotResponse {
  text: string;
  quickReplies?: string[];
}