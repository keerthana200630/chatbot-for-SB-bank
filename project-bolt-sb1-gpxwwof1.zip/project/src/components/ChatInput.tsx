import React, { useState, useRef, KeyboardEvent } from 'react';
import { Send, Paperclip, Mic } from 'lucide-react';

interface ChatInputProps {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
  disabled?: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ 
  value, 
  onChange, 
  onSend,
  disabled = false
}) => {
  const inputRef = useRef<HTMLTextAreaElement>(null);
  
  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSend();
    }
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const textarea = e.target;
    onChange(textarea.value);
    
    // Auto-resize text area
    textarea.style.height = 'auto';
    textarea.style.height = `${Math.min(textarea.scrollHeight, 120)}px`;
  };
  
  return (
    <div className="border-t border-neutral-200 bg-white p-3">
      <div className="flex items-end gap-2">
        <button 
          className="p-2 text-neutral-500 hover:text-primary-600 hover:bg-primary-50 rounded-full transition-colors"
          aria-label="Attach file"
        >
          <Paperclip className="w-5 h-5" />
        </button>
        
        <div className="flex-1 relative">
          <textarea
            ref={inputRef}
            className="w-full border border-neutral-300 rounded-2xl px-4 py-3 pr-12 resize-none focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent min-h-[44px] max-h-[120px]"
            placeholder="Type your message..."
            rows={1}
            value={value}
            onChange={handleChange}
            onKeyDown={handleKeyDown}
            disabled={disabled}
          />
          <button
            className="absolute right-3 bottom-2 p-1.5 bg-primary-600 text-white rounded-full hover:bg-primary-700 transition-colors disabled:opacity-50 disabled:bg-neutral-400"
            onClick={onSend}
            disabled={!value.trim() || disabled}
            aria-label="Send message"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        
        <button 
          className="p-2 text-neutral-500 hover:text-primary-600 hover:bg-primary-50 rounded-full transition-colors"
          aria-label="Voice input"
        >
          <Mic className="w-5 h-5" />
        </button>
      </div>
      
      <div className="mt-2 text-xs text-neutral-500 text-center">
        <p>This conversation may be monitored for quality assurance</p>
      </div>
    </div>
  );
};

export default ChatInput;