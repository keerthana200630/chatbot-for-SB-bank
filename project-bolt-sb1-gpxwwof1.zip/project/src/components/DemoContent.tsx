import React from 'react';
import { ShieldCheck, CreditCard, Clock, DollarSign, Lock, BarChart, ChevronsRight } from 'lucide-react';

const DemoContent: React.FC = () => {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <header className="flex justify-between items-center border-b border-neutral-200 pb-4 mb-8">
        <div className="flex items-center">
          <div className="bg-primary-600 text-white p-2 rounded-lg mr-3">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h1 className="text-2xl font-bold text-neutral-800">SecureBank</h1>
        </div>
        <nav className="hidden md:block">
          <ul className="flex items-center space-x-8">
            <li><a href="#" className="text-neutral-600 hover:text-primary-600 font-medium">Accounts</a></li>
            <li><a href="#" className="text-neutral-600 hover:text-primary-600 font-medium">Transfers</a></li>
            <li><a href="#" className="text-neutral-600 hover:text-primary-600 font-medium">Payments</a></li>
            <li><a href="#" className="text-neutral-600 hover:text-primary-600 font-medium">Investments</a></li>
            <li><a href="#" className="text-neutral-600 hover:text-primary-600 font-medium">Support</a></li>
          </ul>
        </nav>
        <button className="hidden md:block bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition-colors">
          Sign In
        </button>
      </header>

      <main>
        <section className="mb-16">
          <div className="rounded-xl bg-gradient-to-r from-primary-700 to-primary-500 p-8 text-white shadow-lg">
            <h2 className="text-3xl font-bold mb-4">Banking Made Simple</h2>
            <p className="text-lg mb-6 max-w-2xl">Secure, convenient, and reliable banking services designed for your financial needs.</p>
            <div className="flex gap-4">
              <button className="bg-white text-primary-600 px-6 py-3 rounded-lg font-semibold hover:bg-neutral-100 transition-colors">
                Open an Account
              </button>
              <button className="bg-transparent border border-white text-white px-6 py-3 rounded-lg font-semibold hover:bg-white/10 transition-colors">
                Learn More
              </button>
            </div>
          </div>
        </section>

        <section className="mb-16">
          <h2 className="text-2xl font-bold mb-6 text-neutral-800">Our Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: <CreditCard className="w-8 h-8 text-primary-600" />,
                title: 'Digital Banking',
                description: 'Access your accounts anytime, anywhere with our secure online and mobile banking platforms.'
              },
              {
                icon: <Clock className="w-8 h-8 text-primary-600" />,
                title: 'Instant Transfers',
                description: 'Send money to anyone, anywhere, instantly with our fast and secure transfer services.'
              },
              {
                icon: <DollarSign className="w-8 h-8 text-primary-600" />,
                title: 'Financial Planning',
                description: 'Plan your future with our comprehensive financial advisory and retirement planning services.'
              },
              {
                icon: <Lock className="w-8 h-8 text-primary-600" />,
                title: 'Secure Transactions',
                description: 'Rest easy knowing all your transactions are protected with state-of-the-art security measures.'
              },
              {
                icon: <BarChart className="w-8 h-8 text-primary-600" />,
                title: 'Investment Options',
                description: 'Grow your wealth with our diverse range of investment products and portfolio management services.'
              },
              {
                icon: <ShieldCheck className="w-8 h-8 text-primary-600" />,
                title: '24/7 Support',
                description: 'Our dedicated support team is available around the clock to assist you with any banking needs.'
              }
            ].map((service, index) => (
              <div 
                key={index} 
                className="bg-white p-6 rounded-xl shadow-sm border border-neutral-200 hover:shadow-md transition-shadow"
              >
                <div className="mb-4">{service.icon}</div>
                <h3 className="text-xl font-semibold mb-2 text-neutral-800">{service.title}</h3>
                <p className="text-neutral-600">{service.description}</p>
                <a href="#" className="inline-flex items-center mt-4 text-primary-600 hover:text-primary-700 font-medium">
                  Learn more <ChevronsRight className="w-4 h-4 ml-1" />
                </a>
              </div>
            ))}
          </div>
        </section>

        <section className="mb-16">
          <div className="bg-neutral-100 rounded-xl p-8">
            <h2 className="text-2xl font-bold mb-6 text-neutral-800">Need Assistance?</h2>
            <p className="text-lg mb-4 text-neutral-700">
              Our customer support team is here to help you with any banking questions or issues.
            </p>
            <p className="mb-6 text-neutral-600">
              Click the chat icon in the bottom right corner to start a conversation with our virtual assistant.
            </p>
            <div className="flex gap-4">
              <button className="bg-primary-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-primary-700 transition-colors">
                Contact Support
              </button>
              <button className="bg-white text-primary-600 border border-primary-600 px-6 py-3 rounded-lg font-semibold hover:bg-primary-50 transition-colors">
                FAQ
              </button>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-neutral-200 pt-8 mt-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-bold text-neutral-800 mb-4">SecureBank</h3>
            <p className="text-neutral-600 mb-4">Providing secure and innovative banking solutions since 1995.</p>
          </div>
          
          {[
            {
              title: 'Products',
              links: ['Checking', 'Savings', 'Credit Cards', 'Loans', 'Mortgages']
            },
            {
              title: 'Company',
              links: ['About Us', 'Careers', 'Press', 'Investors', 'Contact Us']
            },
            {
              title: 'Resources',
              links: ['Blog', 'Help Center', 'Privacy', 'Terms', 'Security']
            }
          ].map((column, index) => (
            <div key={index}>
              <h3 className="font-bold text-neutral-800 mb-4">{column.title}</h3>
              <ul className="space-y-2">
                {column.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a href="#" className="text-neutral-600 hover:text-primary-600 transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        
        <div className="border-t border-neutral-200 pt-6 pb-8 text-center text-neutral-600 text-sm">
          <p>© 2025 SecureBank. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default DemoContent;