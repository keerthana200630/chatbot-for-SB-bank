import React from 'react';

interface QuickRepliesProps {
  replies: string[];
  onClick: (reply: string) => void;
}

const QuickReplies: React.FC<QuickRepliesProps> = ({ replies, onClick }) => {
  return (
    <div className="mt-2 flex flex-wrap gap-2 max-w-[90%]">
      {replies.map((reply, index) => (
        <button
          key={index}
          className="bg-white border border-primary-200 text-primary-700 rounded-full px-3 py-1.5 text-sm hover:bg-primary-50 transition-colors"
          onClick={() => onClick(reply)}
        >
          {reply}
        </button>
      ))}
    </div>
  );
};

export default QuickReplies;