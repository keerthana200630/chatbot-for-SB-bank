import React from 'react';
import { UserCircle2, Notebook as Robot, ThumbsUp, ThumbsDown } from 'lucide-react';
import { Message } from '../types/chat';
import QuickReplies from './QuickReplies';

interface ChatMessageProps {
  message: Message;
  onQuickReplyClick: (reply: string) => void;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message, onQuickReplyClick }) => {
  const { text, isUser, timestamp, quickReplies } = message;
  
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  return (
    <div className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} animate-slide-up mb-4`}>
      <div className="flex items-start gap-2">
        {!isUser && (
          <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0">
            <Robot className="w-5 h-5 text-primary-700" />
          </div>
        )}
        
        <div className={`chat-message ${isUser ? 'chat-message-user' : 'chat-message-bot'}`}>
          <div className="whitespace-pre-wrap">{text}</div>
          <div className={`text-xs mt-1 ${isUser ? 'text-primary-200' : 'text-neutral-500'}`}>
            {formatTime(timestamp)}
          </div>
        </div>
        
        {isUser && (
          <div className="w-8 h-8 rounded-full bg-neutral-200 flex items-center justify-center flex-shrink-0">
            <UserCircle2 className="w-5 h-5 text-neutral-600" />
          </div>
        )}
      </div>
      
      {!isUser && quickReplies && quickReplies.length > 0 && (
        <QuickReplies replies={quickReplies} onClick={onQuickReplyClick} />
      )}
      
      {!isUser && (
        <div className="flex mt-1 ml-10 gap-2">
          <button 
            className="text-neutral-400 hover:text-success-600 p-1 rounded-full hover:bg-neutral-100 transition-colors"
            aria-label="Helpful"
          >
            <ThumbsUp className="w-3.5 h-3.5" />
          </button>
          <button 
            className="text-neutral-400 hover:text-error-600 p-1 rounded-full hover:bg-neutral-100 transition-colors"
            aria-label="Not helpful"
          >
            <ThumbsDown className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};

export default ChatMessage;