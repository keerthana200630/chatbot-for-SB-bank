import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, X, Send, UserCircle2, Notebook as Robot, ExternalLink, Mic, ThumbsUp, ThumbsDown } from 'lucide-react';
import ChatHeader from './ChatHeader';
import ChatInput from './ChatInput';
import ChatMessage from './ChatMessage';
import QuickReplies from './QuickReplies';
import { Message, ChatState } from '../types/chat';
import { generateBotResponse } from '../utils/chatbot';

const ChatWidget: React.FC = () => {
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [chatState, setChatState] = useState<ChatState>({
    messages: [],
    isTyping: false,
    currentQuery: '',
  });
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  
  const toggleChat = () => {
    setIsExpanded(!isExpanded);
    if (!isExpanded && chatState.messages.length === 0) {
      // Show welcome message when first opened
      setTimeout(() => {
        addBotMessage("Hello! I'm your SecureBank virtual assistant. How can I help you today?", [
          "Check account balance",
          "Recent transactions",
          "Transfer money",
          "Report lost card"
        ]);
      }, 600);
    }
  };
  
  const addUserMessage = (text: string) => {
    if (!text.trim()) return;
    
    const newMessages = [
      ...chatState.messages,
      { id: Date.now(), text, isUser: true, timestamp: new Date() }
    ];
    
    setChatState({
      ...chatState,
      messages: newMessages,
      isTyping: true,
      currentQuery: ''
    });
    
    // Simulate bot thinking time
    setTimeout(() => {
      handleBotResponse(text);
    }, 1000 + Math.random() * 1000);
  };
  
  const addBotMessage = (text: string, quickReplies?: string[]) => {
    const newMessage: Message = {
      id: Date.now(),
      text,
      isUser: false,
      timestamp: new Date(),
      quickReplies
    };
    
    setChatState(prev => ({
      ...prev,
      messages: [...prev.messages, newMessage],
      isTyping: false
    }));
  };
  
  const handleBotResponse = (query: string) => {
    const response = generateBotResponse(query);
    addBotMessage(response.text, response.quickReplies);
  };
  
  const handleInputChange = (value: string) => {
    setChatState({
      ...chatState,
      currentQuery: value
    });
  };
  
  const handleSendMessage = () => {
    if (chatState.currentQuery.trim()) {
      addUserMessage(chatState.currentQuery);
    }
  };
  
  const handleQuickReplyClick = (reply: string) => {
    addUserMessage(reply);
  };
  
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatState.messages, chatState.isTyping]);
  
  if (!isExpanded) {
    return (
      <div 
        className="chat-widget-collapsed"
        onClick={toggleChat}
        aria-label="Open chat support"
      >
        <MessageSquare className="w-6 h-6" />
      </div>
    );
  }
  
  return (
    <div className="chat-widget-expanded animate-fade-in">
      <ChatHeader onClose={toggleChat} />
      
      <div 
        ref={messagesContainerRef}
        className="flex-1 p-4 overflow-y-auto bg-neutral-50 flex flex-col"
      >
        {chatState.messages.map((message) => (
          <ChatMessage 
            key={message.id} 
            message={message} 
            onQuickReplyClick={handleQuickReplyClick}
          />
        ))}
        
        {chatState.isTyping && (
          <div className="chat-message chat-message-bot py-2 px-4 animate-pulse">
            <div className="typing-indicator">
              <span></span>
              <span></span>
              <span></span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      
      <ChatInput 
        value={chatState.currentQuery}
        onChange={handleInputChange}
        onSend={handleSendMessage}
        disabled={chatState.isTyping}
      />
    </div>
  );
};

export default ChatWidget;