import React from 'react';
import { X, ExternalLink } from 'lucide-react';

interface ChatHeaderProps {
  onClose: () => void;
}

const ChatHeader: React.FC<ChatHeaderProps> = ({ onClose }) => {
  return (
    <div className="bg-primary-600 text-white px-4 py-3 flex items-center justify-between">
      <div className="flex items-center">
        <div className="mr-3 w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
          <span className="text-white font-semibold text-sm">SB</span>
        </div>
        <div>
          <h3 className="font-semibold text-sm">SecureBank Support</h3>
          <p className="text-xs text-primary-100">We typically reply in a few minutes</p>
        </div>
      </div>
      <div className="flex items-center">
        <button 
          className="p-1 rounded-full hover:bg-primary-700 mr-2 transition-colors"
          aria-label="Open in new window"
        >
          <ExternalLink className="w-5 h-5" />
        </button>
        <button 
          className="p-1 rounded-full hover:bg-primary-700 transition-colors"
          onClick={onClose}
          aria-label="Close chat"
        >
          <X className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default ChatHeader;